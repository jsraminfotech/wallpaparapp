package com.jsrinfotech.wallpaparapp.globle;

/**
 * Created by Jack sparrow on 27-07-2019.
 */

public class Const {
    public static String IMAGEURL = "";
    public static String CATNAME = "";
}
