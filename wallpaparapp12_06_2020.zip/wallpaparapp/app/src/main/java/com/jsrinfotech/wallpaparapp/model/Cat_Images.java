package com.jsrinfotech.wallpaparapp.model;

/**
 * Created by Jack sparrow on 26-07-2019.
 */

public class Cat_Images {
    public String id;
    public String img;
}
